package com.example.gallery_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GalleryServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
